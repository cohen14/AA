███████╗███████╗██╗     ██╗███╗   ██╗██╗   ██╗██╗  ██╗
██╔════╝██╔════╝██║     ██║████╗  ██║██║   ██║╚██╗██╔╝
███████╗█████╗  ██║     ██║██╔██╗ ██║██║   ██║ ╚███╔╝
╚════██║██╔══╝  ██║     ██║██║╚██╗██║██║   ██║ ██╔██╗
███████║███████╗███████╗██║██║ ╚████║╚██████╔╝██╔╝ ██╗
╚══════╝╚══════╝╚══════╝╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝


SELIUNX SENDERS https://www.youtube.com/watch?v=-1acx0KMLF8&t=2s
NOTE : ON VIDEO TUTOR WILL SHOW YOU SET ALL THINGS ON DAVID.PHP..BUT U NEED TO SET IT ON CONFIG.PHP NOW..NOT IN DAVID.PHP ANYMORE..


                                =======[ THANKS FOR USING THIS SENDER ]=======
IF YOU WANT RENEW YOUR SENDER TOKEN AND GET MORE 1 MONTH, U CAN PAY ONLY 150$ 2 OR 3 DAYS BEFORE ITS EXPIRE.
YOU NEEED TO PAY 200$ IF Your  1 MONTH SENDER  ALREADY OUT OF DATE...THANKS!

╔╦╗╔═╗╦═╗╔╦╗  ╔═╗╔═╗  ╔═╗╔═╗╦═╗╦  ╦╦╔═╗╔═╗
 ║ ║╣ ╠╦╝║║║  ║ ║╠╣   ╚═╗║╣ ╠╦╝╚╗╔╝║║  ║╣
 ╩ ╚═╝╩╚═╩ ╩  ╚═╝╚    ╚═╝╚═╝╩╚═ ╚╝ ╩╚═╝╚═╝

1. Expire on 1 Months
2. Gruantee inbox
3. Out From Member/Banned If Sell This Stuff Or Share Token Ilegal


[
REPORT ANY ERROR TO -->
icq 743695769
]


[ I WILL NOT HELP ANY PEOPLE WHO DONT BUY THIS SENDER FROM ME IF THEY GET ERROR ON THIS SENDER !!! ]


[

Format letter:
     		##email## : replace the contents of the letter to show the recipient's email
     		##subject## : Using random subject
     		##frommail## : Using random From mail
     		##fromname## : Using random From name
     		##short## : Using random your URL
     		##country## : Using random country around the world
     		##date## : Using date time. (NOT RANDOM)
			##country## : Using random country around the world
     		##date## : Using date time. (NOT RANDOM)
    		##OS## : Using random Operating Systems
    		##browser## : Using random Browsers
Rondom Email : ##randstring##.##randstring##@##randstring##.apple.com <--- Change Domain Address
// FROM NAME FOR SPAMMING :

NB-->

1. RIGHT CLICK ON SELIUNX Folder ON LEFT SIDE
2. CHOOSE 'Open Terminal Here'
3. PUT COMMAND 'php DAVID.php'

]

[

--> SMTP settings <--

smtpserver --> Fill in with the smtp server you're using
smtpuser   --> Fill in with the smtp user you're using
smtppass   --> Fill in the smtp password you use
smtpport   --> Fill in with the smtp port you're using
priority   --> Fill 1 for high priority, fill 0 for normal priority

--> End <--

--> Mail settings <--

mailist  --> Fill in the name of your mailist file.
fromname --> Fill the fromname to your liking. If you use the userandom feature, you do not need to fill in this section.
frommail --> Fill frommail to your liking. If you use the userandom feature, you do not need to fill in this section.
subject  --> Fill frommail to your liking. If you use the userandom feature, you do not need to fill in this section.
msgfile  --> Fill in your letter file name.

--> End <--


--> Other <--

userremoveline --> Fill 1 to use. 0 for not. If this feature is enabled, email-list already sent messages will be removed from your mailist.
replacement    --> Fill 1 to use. 0 for not. This works to me replace your letter with a predefined format.
ratio      --> Ratio Email Per Send.
sleeptime      --> Duration of sending pauses per email in seconds.
randurl        --> This is a random url feature. Serves to randomize the url with the url you have specified. How to fill it is as follows-->   randurl = array ("http-->//yoururl1.com", "http-->//yoururl2.com", "etc");

--> End <--
                                =======[ THANKS FOR USING THIS SENDER ]=======